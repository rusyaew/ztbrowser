/*
 * jsrsasign(davetest) 10.9.9 (2023-04-14) (c) 2010-2023 Kenji Urushima | kjur.github.io/jsrsasign/license
 */
var VERSION = "10.9.9";
var VERSION_FULL = "jsrsasign(davetest) 10.9.9 (2023-04-14) (c) 2010-2023 Kenji Urushima | kjur.github.io/jsrsasign/license";

